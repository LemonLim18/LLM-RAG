"""Code-reviewed handler IDs only; catalog data can never import Python code."""

VALIDATION_HANDLERS = ("network_values_v1", "unique_interfaces_v1", "safe_strings_v1")
NORMALIZATION_HANDLERS = {"ipv4_prefix_length"}


def validate_object_requirements(schema):
    from jsonschema import Draft202012Validator
    from .models import ConditionalRequirement
    properties = schema.get("properties", {})
    conditions = schema.get("x-conditional-required", [])
    dependencies = schema.get("dependentRequired", {})
    if (conditions or dependencies) and schema.get("type") != "object":
        raise ValueError("Conditional requirements belong on an object schema.")
    if not isinstance(conditions, list):
        raise ValueError("x-conditional-required must be an array of reviewed conditions.")
    if not isinstance(dependencies, dict):
        raise ValueError("dependentRequired must be an object of field-name arrays.")
    for raw in conditions:
        rule = ConditionalRequirement.model_validate(raw)
        if rule.field not in properties or any(name not in properties for name in rule.required):
            raise ValueError("Conditional requirement references an undefined local property.")
        if len(set(rule.required)) != len(rule.required) or not Draft202012Validator(properties[rule.field]).is_valid(rule.equals):
            raise ValueError("Invalid conditional required fields or comparison value.")
    for field, required in dependencies.items():
        if (not isinstance(required, list) or any(not isinstance(name, str) for name in required)
                or len(set(required)) != len(required)):
            raise ValueError("dependentRequired values must be unique field-name arrays.")
        if field not in properties or any(name not in properties for name in required):
            raise ValueError("dependentRequired references an undefined property.")


def required_fields(schema, params):
    from jsonschema import Draft202012Validator
    required = list(schema.get("required", []))
    for field, dependencies in schema.get("dependentRequired", {}).items():
        if field in params:
            required.extend(dependencies)
    for rule in schema.get("x-conditional-required", []):
        if rule["field"] in params and Draft202012Validator({"const": rule["equals"]}).is_valid(params[rule["field"]]):
            required.extend(rule["required"])
    return list(dict.fromkeys(required))


def normalize_prefix(value, prompt):
    from ..parameters.normalizer import prefix_length_from_text
    explicit = prefix_length_from_text(prompt)
    if explicit is None:
        return None, None
    try:
        candidate = int(value)
    except (TypeError, ValueError):
        candidate = explicit
    if candidate != explicit:
        return None, None
    return explicit, "derived_from_user_netmask" if "mask" in prompt.lower() else "user"


def validate_handler_ids(schema: dict) -> list[str]:
    handlers = schema.get("x-validation-handlers", list(VALIDATION_HANDLERS))
    if not isinstance(handlers, list) or any(not isinstance(value, str) for value in handlers):
        raise ValueError("Validation handlers must be a list of registered IDs.")
    if len(set(handlers)) != len(handlers) or set(handlers) != set(VALIDATION_HANDLERS):
        raise ValueError("Unknown or missing mandatory validation handler.")
    return handlers


def validation_issues(params: dict, schema: dict) -> list:
    from ..parameters.validator import _network_value_issues, _unique_interface_issues, _safe_string_issues

    handlers = dict(zip(VALIDATION_HANDLERS, (_network_value_issues, _unique_interface_issues, _safe_string_issues)))
    return [issue for name in validate_handler_ids(schema) for issue in handlers[name](params)]


def derive_template_value(handler: str, params: dict):
    if handler != "ipv4_netmask_v1":
        raise ValueError(f"Unknown template derivation: {handler}")
    import ipaddress
    return str(ipaddress.IPv4Network(f"0.0.0.0/{params['prefix_length']}").netmask)
