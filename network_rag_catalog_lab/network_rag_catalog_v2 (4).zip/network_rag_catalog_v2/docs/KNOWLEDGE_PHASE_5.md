# Knowledge Backend: Phase 5 Handoff

Status: implemented with the user's JSON-authoritative constraint. The proposed
SQLite authority cutover/database migrations were deliberately deferred, not
silently implemented as a second writable source. No GUI or HTTP server exists.

## Backend Model

```text
CLI / future authenticated API
  -> strict request/result contracts
  -> knowledge management service + dependency/impact checks
  -> revision-checked JSON authoring + recovery journal
  -> explicit validate / preview / publish
  -> immutable Phase 4 runtime release
  -> existing intent, clarification, validation and rendering pipeline
```

- `app/api/contracts.py`: typed edit/import/publication envelopes, entity changes,
  complete operation-contract inputs, versioned catalog exports, structured issues
  and results. Results contain `ok`, `revision`, `data`, `issues`, and `warnings`.
- `app/knowledge/management.py`: create/edit/retire categories; create/edit
  parameters; assign/unassign memberships; create/edit/retire operations; replace
  operation mappings/rules/template bindings coherently; preview, validate,
  impact/dry-run, export/import and publication use cases.
- `app/knowledge/document_repository.py`: defensive candidate-document reads
  through the existing repository contract, tested against file-backed reads.
- `app/knowledge/authoring_store.py`: exclusive local writer lock, expected-revision
  checks, atomic replacement of individual JSON files, multi-file journal and
  rollback/recovery. It records actor, reason, before/after contents and revisions.
- `app/knowledge/cli.py`: JSON request files and JSON results, exit 0 for success,
  1 for rejected operations. Existing `main.py` and public runtime APIs remain.

## First Use

Use the existing environment from the V2 directory. Inspecting or validating does
not require a publication and does not alter catalog contents.

```text
python -m app.knowledge.cli inspect
python -m app.knowledge.cli validate
python -m app.knowledge.cli preview-schema configure_ospf --vendor cisco
```

Before the first management write, publish the reviewed baseline, choosing either
normal indexed publication or deliberate offline mode:

```text
python -m app.knowledge.publication --verify-legacy
python -m app.knowledge.publication --offline --verify-legacy
```

Run only the mode wanted. No baseline was activated against the real workspace
during development. After activation, JSON edits are drafts: live requests keep
using the published release until an explicit successful publication.

An edit request has this shape, with the revision returned by `inspect`:

```json
{
  "expected_revision": "<current revision>",
  "actor": "senior-engineer",
  "reason": "Clarify category description",
  "changes": [{
    "entity": "category",
    "action": "update",
    "entity_id": "vlan",
    "values": {"description": "Reviewed VLAN operations"}
  }]
}
```

```text
python -m app.knowledge.cli apply reviewed-change.json --dry-run
python -m app.knowledge.cli apply reviewed-change.json
python -m app.knowledge.cli validate
python -m app.knowledge.cli publish reviewed-publication.json
```

Publication requests require `expected_revision`, `expected_release` (null for
initial publication), `actor`, `reason`, and `mode` (`chroma` or `offline`). A stale
draft revision or release ID rejects the request instead of overwriting new work.
`inspect` returns both current values. The optional CLI `--project PATH` precedes
the subcommand and selects another local project root.

## Editing Contracts

Entity/action combinations:

| Entity | Actions | Values |
| --- | --- | --- |
| category | create, update, retire, delete | Category metadata |
| parameter | create, update, delete | Shared definition, no operation rules |
| operation | create, update, retire, delete | Operation metadata |
| membership | assign, unassign | category_id and parameter_id |
| contract | replace | version, mappings, rules, templates |
| context_rules | replace | Complete reviewed context-rules document |

Contract replacement requires all records to use the selected operation ID and
version; use the existing JSON record shapes. It replaces only that operation's
rows in the three catalogs and sets registry authority. Shared metadata changes
do not rename payload keys. `preview-schema` exposes the compiled draft, optionally
with one supported vendor's requirements.

New operations default to inactive. An incomplete inactive draft may be authored
incrementally, with a warning, but cannot be published until completed or deleted.
The current authoring catalog is one draft workspace, not independent draft
branches or partial per-operation publishing. Activation uses an operation update
to `status: active` after its contract/templates are complete and reviewed.

Deletion never cascades. Referenced parameters/memberships/categories cannot be
removed; any previously published identity is retained even after retirement.
Planned-context references also block operation deletion. Retiring a category
requires its active operations to be retired in the same batch or beforehand.
Review impact reports; shared metadata reports all operations conservatively.

## Export, Audit and Recovery

`python -m app.knowledge.cli export` returns a version-1 bundle under `data.bundle`.
Import requests contain `expected_revision`, `actor`, `reason`, and `bundle`.
Use `python -m app.knowledge.cli import reviewed-import.json`. Imports run the same
validation and published-identity protections as edits.

Exports contain managed catalog documents and hashes of the required existing
schema/template assets, not arbitrary executable template uploads. Restore those
assets separately from source control before importing; mismatched assets reject
the import. The migration manifest and inventory/planned data are not management
entities and are not overwritten by imports.

Journals are under `storage/catalog_authoring/`. Published manifests contain the
publication actor/reason. These are local audit records, not authenticated or
tamper-proof identity proof. An interrupted transaction leaves a pending marker;
cooperating source readers and publishers refuse to consume partial authoring.
Published requests keep using the previous immutable release.

```text
python -m app.knowledge.cli recover
```

Recovery rolls back a prepared transaction or completes cleanup for a committed
one. It refuses to overwrite unrelated edits. A hard process crash may leave
`data/catalog/.authoring.lock`; it records the writer PID. Verify the writer has
stopped before manually removing this lock, then recover. Do not delete journals
or pending markers to bypass recovery. A lock on another host/cloud-sync conflict
cannot be safely diagnosed automatically.

## Verification and Remaining Work

Final compatibility run: **145 tests passed** using the existing environment.
The read-only migration comparison reports **12 operations, zero differences**;
Phase 4 tests compare all **36 vendor template outputs**. `git diff --check` passes.
Read-only CLI validation succeeds against the current workspace catalog.

Focused tests cover management lifecycle/dependencies, scoped contract updates,
draft/live separation, previews, strict requests, stale revisions, JSON CLI exit
codes, metadata export/import, repository equivalence, exact-byte rollback,
interrupted writes, and refusal to overwrite external edits. The original runtime
regressions and Phase 4 schema/template comparisons remain in the suite.

Remaining work:

- Review this revision and run a live indexed publication with the installed
  model, followed by representative terminal clarification prompts.
- Validate templates against the actual device/OS combinations. No lab/device
  certification or external execution was performed.
- Review target-document definitions still listed in `migration_manifest.json`.
- Authoring coordination is local/single-host and cooperative. Filesystem JSON
  replacement is not a database transaction across arbitrary readers or cloud
  sync. Do not run concurrent writers through OneDrive or another host.
- If database authority is later approved, implement a deliberate migration and
  adapter; do not introduce parallel editable JSON/SQLite/PostgreSQL authorities.
- Add authentication, authorization, stronger audit retention and operational
  controls before exposing management over a network. No server/frontend,
  Ansible, topology, or external-tool integration was added.
