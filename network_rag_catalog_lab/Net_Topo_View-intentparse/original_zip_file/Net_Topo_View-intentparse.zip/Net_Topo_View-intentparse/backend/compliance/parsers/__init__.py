"""Vendor lightweight config parsers."""

