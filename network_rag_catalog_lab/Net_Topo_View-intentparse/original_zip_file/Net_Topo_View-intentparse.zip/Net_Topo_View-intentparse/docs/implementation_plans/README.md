# Module Implementation Plans

This folder stores the implementation plan for each module as development progresses.

| Module | File | Status |
|--------|------|--------|
| **M1** Multi-Vendor Driver Layer | [M1_MultiVendor_DriverLayer.md](M1_MultiVendor_DriverLayer.md) | ✅ Done |
| **M2** Topology Crawler | — | 🔴 Not Started |
| **M3** Configuration Engine | [M3_ConfigurationEngine.md](M3_ConfigurationEngine.md) | 🟡 Planning |
| **M4** Deployment Pipeline | — | 🔴 Not Started |
| **M5** LLM Agent | — | 🔴 Not Started |
| **M6** MCP Server | — | 🔴 Not Started |
| **M7** NetBox Integration | — | 🔴 Not Started |
| **M8** Drift Detection | — | 🔴 Not Started |
| **M9** Frontend Dashboard | — | 🔴 Not Started |
| **M10** Frontend Topology | — | 🔴 Not Started |
| **M11** Frontend Chat + Config | — | 🔴 Not Started |
| **M12** Frontend Security Dashboard | — | 🔴 Not Started |
| **M13** Security Module | — | 🔴 Not Started |
| **M14** Database Layer | — | 🔴 Not Started |
| **M15** Auth & Credentials | — | 🔴 Not Started |
| **M16** Task Scheduler | — | 🔴 Not Started |
| **M17** Network Performance | — | 🔴 Not Started |
| **M18** QoS Remediation | — | 🔴 Not Started |
| **M19** Agentic Config Workflow | [M19_AgenticConfigWorkflow.md](M19_AgenticConfigWorkflow.md) | ✅ Done |
| **M20** SSH Terminal | [M20_SSHTerminal.md](M20_SSHTerminal.md) | ✅ Done |

See [module.md](../../module.md) for the full module architecture.
