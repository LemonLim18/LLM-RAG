"""Review coherent packs using existing management envelopes, never direct SQL."""

from copy import deepcopy
import json
from pathlib import Path

from ..api.contracts import EntityChange, OperationContractInput
from .models import Category, Operation, ParameterDefinition
from .runtime import safe_path


def read_pack(path):
    root = Path(path).resolve()
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("format_version") != 1:
        raise ValueError("Unsupported knowledge pack format.")
    changes = [EntityChange.model_validate(row) for row in json.loads((root / "changes.json").read_text(encoding="utf-8"))]
    context = json.loads((root / "context_rules.json").read_text(encoding="utf-8"))
    assets = {}
    for relative in manifest["assets"]:
        if not relative.startswith("data/templates/") or not relative.endswith("/template.j2"):
            raise ValueError(f"Pack asset is not a template: {relative}")
        assets[relative] = safe_path(root / "assets", relative).read_bytes()
    return {"manifest": manifest, "changes": changes, "context": context, "assets": assets}


def install_reviewed_assets(pack, base_dir):
    """Explicit caller action; never overwrite an existing template with new bytes."""
    paths = {name: safe_path(Path(base_dir), name) for name in pack["assets"]}
    for name, path in paths.items():
        if path.exists() and path.read_bytes() != pack["assets"][name]:
            raise ValueError(f"Conflicting template asset; review a versioned update: {name}")
    for name, path in paths.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            with path.open("xb") as stream:
                stream.write(pack["assets"][name])


def prepare_request(manager, pack, *, actor, reason):
    """Idempotent diff only: existing but different records require engineer review."""
    snapshot = manager.store.snapshot()
    rows = snapshot["catalogs"]
    changes = []
    models = {"category": ("categories", "category_id", Category),
              "parameter": ("parameters", "parameter_id", ParameterDefinition),
              "operation": ("operations", "operation_id", Operation)}
    for change in pack["changes"]:
        if change.entity in models and change.action == "create":
            name, key, model = models[change.entity]
            existing = next((row for row in rows[name] if row[key] == change.entity_id), None)
            if existing is not None:
                expected = {**change.values, key: change.entity_id}
                if model.model_validate(existing).model_dump() != model.model_validate(expected).model_dump():
                    raise ValueError(f"Pack conflicts with reviewed {change.entity} {change.entity_id}.")
                continue
        elif change.entity == "membership" and change.action == "assign":
            if change.values in rows["category_parameters"]:
                continue
        elif change.entity == "contract" and change.action == "replace":
            existing = next((row for row in rows["operations"] if row["operation_id"] == change.entity_id), None)
            if existing:
                current = {"version": existing["version"], **{key: [row for row in rows[name] if row["operation_id"] == change.entity_id]
                    for key, name in (("mappings", "operation_parameters"), ("rules", "operation_rules"), ("templates", "template_bindings"))}}
                if OperationContractInput.model_validate(current) != OperationContractInput.model_validate(change.values):
                    raise ValueError(f"Pack conflicts with reviewed contract {change.entity_id}.")
                continue
        else:
            raise ValueError("Packs only create records, assign memberships and install complete new contracts.")
        changes.append(change.model_dump())
    context = deepcopy(rows["context_rules"])
    for operation_id, rule in pack["context"].items():
        if operation_id in context["operations"] and context["operations"][operation_id] != rule:
            raise ValueError(f"Pack conflicts with reviewed context rules for {operation_id}.")
        context["operations"][operation_id] = rule
    if context != rows["context_rules"]:
        changes.append({"entity": "context_rules", "action": "replace", "values": context})
    if not changes:
        return None
    return {"expected_revision": snapshot["revision"], "actor": actor, "reason": reason, "changes": changes}
