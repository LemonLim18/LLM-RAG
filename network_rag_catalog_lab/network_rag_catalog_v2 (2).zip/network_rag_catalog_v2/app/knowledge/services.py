"""Read-only knowledge use cases and catalog metadata integrity checks."""

from collections.abc import Sequence
from typing import TypeVar

from .migration import SchemaParameterReference
from .models import CatalogRecord, Category, CategoryParameter, Operation, ParameterDefinition
from .repository import KnowledgeRepository


RecordT = TypeVar("RecordT", bound=CatalogRecord)


def _get_by_id(records: Sequence[RecordT], id_field: str, record_id: str) -> RecordT:
    for record in records:
        if getattr(record, id_field) == record_id:
            return record
    raise KeyError(f"Unknown {id_field}: {record_id}")


class KnowledgeService:
    def __init__(self, repository: KnowledgeRepository):
        self.repository = repository

    def list_categories(self) -> list[Category]:
        return self.repository.list_categories()

    def list_operations(self, include_inactive: bool = False) -> list[Operation]:
        records = self.repository.list_operations()
        return records if include_inactive else [record for record in records if record.status == "active"]

    def list_parameters(self) -> list[ParameterDefinition]:
        return self.repository.list_parameters()

    def list_category_parameters(self, category_id: str | None = None) -> list[CategoryParameter]:
        if category_id is not None:
            self.get_category(category_id)
        records = self.repository.list_category_parameters()
        return records if category_id is None else [record for record in records if record.category_id == category_id]

    def parameters_for_category(self, category_id: str) -> list[ParameterDefinition]:
        memberships = self.list_category_parameters(category_id)
        definitions = self.list_parameters()
        return [_get_by_id(definitions, "parameter_id", record.parameter_id) for record in memberships]

    def get_category(self, category_id: str) -> Category:
        return _get_by_id(self.list_categories(), "category_id", category_id)

    def get_operation(self, operation_id: str) -> Operation:
        return _get_by_id(self.list_operations(), "operation_id", operation_id)

    def get_parameter(self, parameter_id: str) -> ParameterDefinition:
        return _get_by_id(self.list_parameters(), "parameter_id", parameter_id)

    def reload(self) -> None:
        self.repository.reload()

    def validate_category_parameters(self, memberships: Sequence[CategoryParameter] | None = None) -> None:
        category_ids = {record.category_id for record in self.list_categories()}
        parameters = {record.parameter_id: record for record in self.list_parameters()}
        pairs = set()
        phrase_owners = {}
        records = self.list_category_parameters() if memberships is None else memberships
        for record in records:
            pair = (record.category_id, record.parameter_id)
            if pair in pairs:
                raise ValueError(f"Duplicate category parameter membership: {pair}")
            pairs.add(pair)
            if record.category_id not in category_ids:
                raise ValueError(f"Membership references unknown category: {record.category_id}")
            if record.parameter_id not in parameters:
                raise ValueError(f"Membership references unknown parameter: {record.parameter_id}")
            parameter = parameters[record.parameter_id]
            for phrase in [parameter.parameter_id, parameter.display_name, *parameter.aliases]:
                key = (record.category_id, phrase.strip().casefold())
                if key in phrase_owners and phrase_owners[key] != parameter.parameter_id:
                    raise ValueError(
                        f"Category {record.category_id} parameter alias '{phrase}' has multiple owners: "
                        f"{phrase_owners[key]}, {parameter.parameter_id}."
                    )
                phrase_owners[key] = parameter.parameter_id

    def validate_schema_membership(self, category_id: str, references: Sequence[SchemaParameterReference]) -> None:
        allowed = {record.parameter_id for record in self.list_category_parameters(category_id)}
        for reference in references:
            if reference.parameter_id not in allowed:
                raise ValueError(
                    f"Category {category_id} does not expose parameter '{reference.parameter_id}' "
                    f"used at '{reference.field_path}'."
                )

    def validate_metadata(self) -> None:
        categories = self.list_categories()
        operations = self.list_operations(include_inactive=True)
        parameters = self.list_parameters()
        for records, key, label in (
            (categories, "category_id", "category"),
            (operations, "operation_id", "operation"),
            (parameters, "parameter_id", "parameter"),
        ):
            seen = set()
            duplicates = set()
            for record in records:
                value = getattr(record, key)
                if value in seen:
                    duplicates.add(value)
                seen.add(value)
            if duplicates:
                raise ValueError(f"Invalid {label} catalog IDs: {sorted(duplicates)}")

        category_ids = {category.category_id for category in categories}
        phrase_owners = {}
        for operation in operations:
            if operation.category_id not in category_ids:
                raise ValueError(
                    f"Operation {operation.operation_id} references unknown category {operation.category_id}."
                )
            for phrase in [operation.display_name, *operation.aliases]:
                key = phrase.strip().casefold()
                if key in phrase_owners and phrase_owners[key] != operation.operation_id:
                    raise ValueError(f"Operation alias '{phrase}' has multiple owners.")
                phrase_owners[key] = operation.operation_id
