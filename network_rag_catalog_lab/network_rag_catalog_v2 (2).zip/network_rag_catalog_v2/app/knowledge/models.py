"""Typed legacy catalog records, without operation schemas or domain rules."""

from typing import Annotated, Literal

from jsonschema import Draft202012Validator
from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator


StableId = Annotated[str, StringConstraints(pattern=r"^[a-z][a-z0-9_]*$")]
NonBlankText = Annotated[str, StringConstraints(min_length=1, pattern=r"\S")]


class CatalogRecord(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, extra="allow")

    display_name: NonBlankText
    aliases: list[NonBlankText] = Field(default_factory=list)
    description: str = ""

    def to_legacy_dict(self) -> dict:
        # Do not inject model defaults into existing callers' dictionary payloads.
        return self.model_dump(exclude_unset=True)


class Category(CatalogRecord):
    category_id: StableId


class ParameterDefinition(CatalogRecord):
    parameter_id: StableId
    value_type: Literal["string", "integer", "number", "boolean", "array", "object", "null"]
    clarification: str = ""
    normalizer: NonBlankText | None = None

    @model_validator(mode="before")
    @classmethod
    def reject_operation_policies(cls, value):
        policy_keys = set(Draft202012Validator.VALIDATORS) | {
            "optional", "validation", "validation_rules", "rules", "schema", "default", "x-required-by-vendor",
        }
        if isinstance(value, dict) and (found := policy_keys.intersection(value)):
            raise ValueError(f"Operation rules belong in operation schemas, not shared parameters: {sorted(found)}")
        return value


class CategoryParameter(BaseModel):
    """Membership only; labels/types remain on the referenced definition."""

    model_config = ConfigDict(strict=True, frozen=True, extra="forbid")

    category_id: StableId
    parameter_id: StableId


class Operation(CatalogRecord):
    operation_id: StableId
    category_id: StableId
    schema_path: NonBlankText
    status: Literal["active", "inactive"] = "active"
    version: Annotated[int, Field(ge=1)] = 1
    use_cases: list[NonBlankText] = Field(default_factory=list)
