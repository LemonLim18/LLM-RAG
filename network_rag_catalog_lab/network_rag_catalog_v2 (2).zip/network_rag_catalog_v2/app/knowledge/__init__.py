"""Read-only intent knowledge foundation; JSON remains authoritative."""
