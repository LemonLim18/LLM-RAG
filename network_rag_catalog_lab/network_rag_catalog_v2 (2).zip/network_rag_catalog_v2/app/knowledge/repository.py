"""Storage-independent catalog reads; authoring writes are a later phase."""

from typing import Protocol

from .models import Category, CategoryParameter, Operation, ParameterDefinition


class KnowledgeRepository(Protocol):
    def list_categories(self) -> list[Category]: ...

    def list_operations(self) -> list[Operation]: ...

    def list_parameters(self) -> list[ParameterDefinition]: ...

    def list_category_parameters(self) -> list[CategoryParameter]: ...

    def reload(self) -> None: ...
