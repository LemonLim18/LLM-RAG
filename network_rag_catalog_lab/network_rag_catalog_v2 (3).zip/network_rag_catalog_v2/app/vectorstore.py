from langchain_chroma import Chroma
from .config import CHROMA_DIR, CHROMA_COLLECTION, OLLAMA_EMBED_MODEL
from .embeddings import embeddings
from .knowledge.runtime import current_snapshot

def get_vectorstore():
    snapshot = current_snapshot()
    if snapshot:
        retrieval = snapshot.manifest["retrieval"]
        if not retrieval["ready"] or retrieval["mode"] != "chroma":
            raise ValueError("This release is offline; choose a literal catalog operation or publish with embeddings.")
        if retrieval["embedding_model"] != OLLAMA_EMBED_MODEL:
            raise ValueError("Embedding model changed; publish a new matching retrieval release.")
        return Chroma(collection_name=retrieval["collection"], persist_directory=str(CHROMA_DIR),
                      embedding_function=embeddings, create_collection_if_not_exists=False)
    from .catalog import load_operations
    if any(operation.get("schema_source") == "registry" for operation in load_operations()):
        raise ValueError("Publish a knowledge release before semantic retrieval; a legacy index cannot serve registry contracts.")
    return Chroma(collection_name=CHROMA_COLLECTION,persist_directory=str(CHROMA_DIR),embedding_function=embeddings)
