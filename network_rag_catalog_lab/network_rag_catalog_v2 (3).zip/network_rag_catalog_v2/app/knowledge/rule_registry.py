"""Code-reviewed handler IDs only; catalog data can never import Python code."""

VALIDATION_HANDLERS = ("network_values_v1", "unique_interfaces_v1", "safe_strings_v1")


def validate_handler_ids(schema: dict) -> list[str]:
    handlers = schema.get("x-validation-handlers", list(VALIDATION_HANDLERS))
    if not isinstance(handlers, list) or any(not isinstance(value, str) for value in handlers):
        raise ValueError("Validation handlers must be a list of registered IDs.")
    if len(set(handlers)) != len(handlers) or set(handlers) != set(VALIDATION_HANDLERS):
        raise ValueError("Unknown or missing mandatory validation handler.")
    return handlers


def validation_issues(params: dict, schema: dict) -> list:
    from ..parameters.validator import _network_value_issues, _unique_interface_issues, _safe_string_issues

    handlers = dict(zip(VALIDATION_HANDLERS, (_network_value_issues, _unique_interface_issues, _safe_string_issues)))
    return [issue for name in validate_handler_ids(schema) for issue in handlers[name](params)]


def derive_template_value(handler: str, params: dict):
    if handler != "ipv4_netmask_v1":
        raise ValueError(f"Unknown template derivation: {handler}")
    import ipaddress
    return str(ipaddress.IPv4Network(f"0.0.0.0/{params['prefix_length']}").netmask)
