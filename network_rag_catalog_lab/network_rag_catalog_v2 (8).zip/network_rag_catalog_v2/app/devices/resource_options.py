"""Suggestions from device-scoped planned facts, never automatic intent defaults."""


def resource_options(policy, device, path, params, revision):
    if not policy:
        return []
    resources = device.get("resources", {})
    fields = {"acl_name": ("acls", "name"), "classifier_name": ("classifiers", "name"),
              "policy_name": ("qos_policies", "name"), "route_policy": ("route_policies", "name"),
              "process_id": ("ospf_processes", "process_id")}
    rows = []
    if path in fields and isinstance(resources, dict):
        collection, identity = fields[path]
        rows = [row.get(identity) for row in resources.get(collection, []) if isinstance(row, dict)]
    elif path == "previous_dscp_values" and isinstance(resources, dict):
        rows = [row.get("dscp_values") for row in resources.get("classifiers", []) if row.get("name") == params.get("classifier_name")]
    elif path == "acl_rule_id" and isinstance(resources, dict):
        rows = [rule.get("acl_rule_id") for acl in resources.get("acls", []) if acl.get("name") == params.get("acl_name")
                for rule in acl.get("rules", []) if rule.get("kind") == "ace"]
    elif path in {"vlan_id", "native_vlan", "allowed_vlans"}:
        rows = [row.get("vlan_id") for row in device.get("vlans", []) if isinstance(row, dict)]
        if path == "allowed_vlans":
            rows = [[value] for value in rows if value is not None]
    return [{"value": value, "label": str(value), "kind": "fact",
             "source_ref": f"inventory:{device['id']}:{path}:{value}", "source_revision": revision,
             "explanation": "Confirm this device-scoped planned resource."}
            for value in rows if value is not None]
