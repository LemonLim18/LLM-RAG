# Requested Operation and Vendor Coverage Audit

Reviewed against the active SQLite-derived runtime on 2026-09-29.

All **35 requested operation IDs already exist and are indexed**. The runtime has
44 operations in total, preserving the original removal, IP, BGP and IS-IS entries.
No duplicate operation identities are needed for individual vendors.

RAG documents now explicitly contain each operation's supported profiles,
per-vendor required/optional fields and vendors with no implemented binding.
Those facts are passed to the operation selector. They describe actual template
coverage; listing an unsupported vendor does not enable configuration generation.

## Actual Generation Coverage

Within the requested list: Cisco 35/35, Huawei 7/35, Juniper 9/35.
This leaves **54 vendor-operation combinations without a binding**.
Supported means a declared generation contract for the existing profiles;
inventory capabilities and resource checks still apply. Device certification
has not been performed.

| Requested operation | Cisco | Huawei | Juniper |
| --- | --- | --- | --- |
| `create_vlan` | Declared | Declared | Declared |
| `modify_vlan` | Declared | Missing binding | Missing binding |
| `rename_vlan` | Declared | Missing binding | Missing binding |
| `delete_vlan` | Declared | Declared | Declared |
| `set_interface_description` | Declared | Declared | Declared |
| `set_interface_admin_state` | Declared | Declared | Declared |
| `configure_access_port` | Declared | Missing binding | Missing binding |
| `configure_trunk_port` | Declared | Missing binding | Missing binding |
| `assign_vlan_to_trunk_port` | Declared | Declared | Declared |
| `configure_trunk_allowed_vlans` | Declared | Missing binding | Missing binding |
| `set_native_vlan` | Declared | Declared | Declared |
| `configure_loopback_interface` | Declared | Missing binding | Missing binding |
| `configure_port_channel` | Declared | Missing binding | Missing binding |
| `configure_static_route` | Declared | Declared | Declared |
| `add_default_route` | Declared | Missing binding | Declared |
| `add_floating_static_route` | Declared | Missing binding | Declared |
| `enable_ospf_process` | Declared | Missing binding | Missing binding |
| `set_ospf_router_id` | Declared | Missing binding | Missing binding |
| `create_ospf_area` | Declared | Missing binding | Missing binding |
| `assign_interface_to_ospf_area` | Declared | Missing binding | Missing binding |
| `advertise_network` | Declared | Missing binding | Missing binding |
| `configure_passive_interface` | Declared | Missing binding | Missing binding |
| `configure_ospf_redistribution` | Declared | Missing binding | Missing binding |
| `create_acl` | Declared | Missing binding | Missing binding |
| `add_acl_rule` | Declared | Missing binding | Missing binding |
| `modify_acl_rule` | Declared | Missing binding | Missing binding |
| `delete_acl_rule` | Declared | Missing binding | Missing binding |
| `apply_acl_to_interface` | Declared | Missing binding | Missing binding |
| `create_qos_policy` | Declared | Missing binding | Missing binding |
| `create_classifier` | Declared | Missing binding | Missing binding |
| `classify_by_dscp` | Declared | Missing binding | Missing binding |
| `configure_scheduler` | Declared | Missing binding | Missing binding |
| `configure_shaping` | Declared | Missing binding | Missing binding |
| `configure_policing` | Declared | Missing binding | Missing binding |
| `apply_qos_policy_to_interface` | Declared | Missing binding | Missing binding |

## Requested Schema Versus Current Contract

The supplied mapping is a first-pass proposal, not a drop-in executable schema.
The current operation-scoped required flags and validation remain authoritative.

| Proposed name/behavior | Current implementation or gap |
| --- | --- |
| `vlan_name` | Create/delete use `name`; rename uses `new_vlan_name`. Do not create a second competing value. |
| `admin_state: up/down` | Current typed field is `admin_up: true/false`. A value conversion is needed before treating these as interchangeable payloads. |
| `ip_address` | Current address field is `address`, with separate `prefix_length`. |
| Port-channel `interface` | Uses `aggregate_interface` and requires explicit LACP mode. |
| ACL `rule_id/protocol/action` | Uses `acl_rule_id/ip_protocol/acl_action`. |
| `bandwidth/rate_limit/burst_size` | Uses explicit `bandwidth_bps/rate_bps/burst_bytes`. Units must not be guessed. |
| Optional OSPF process everywhere | Process requirements are operation/vendor-specific; omitting them cannot silently select an arbitrary process. |
| Bare OSPF area creation | Current addition creates a non-backbone stub area and requires area type/process context. |
| Broad `modify_vlan` | Current operation changes state only; rename has its own operation. General description/name edits need a versioned contract. |
| At least one modification | This means at-least-one presence, not exactly-one. JSON Schema `oneOf` would reject multiple simultaneous changes if used naively. |
| Partial ACL modification | Current operation requires full replacement; partial edits need authoritative complete existing rule values. |
| Optional ACL source/destination/protocol | Current add/replace contracts require explicit matching scope; missing data does not mean any/permit-all. |
| Optional redistribution route policy | Current bounded redistribution requires a recorded default-deny policy. |
| `create_qos_policy` with only name | Current contract requires explicit classifier/bandwidth relationships through `policy_terms`. |
| Portable `scheduler_name` | Current Cisco operation configures bandwidth for a policy/class; this is not a portable standalone scheduler entity. |
| Optional attachment direction | Current ACL/QoS attachments require explicit direction and existing attachment facts. |

## Current Required Fields

These are base schemas. The RAG profile descriptions include vendor-required
overlays; optional properties are included to make the differences reviewable.

| Operation | Required | Optional |
| --- | --- | --- |
| `create_vlan` | `vlan_id` | `name` |
| `modify_vlan` | `vlan_id`, `vlan_status` | None |
| `rename_vlan` | `vlan_id`, `new_vlan_name` | None |
| `delete_vlan` | `vlan_id` | `name` |
| `set_interface_description` | `interface`, `description` | None |
| `set_interface_admin_state` | `interface`, `admin_up` | None |
| `configure_access_port` | `interface`, `vlan_id` | `description` |
| `configure_trunk_port` | `interface`, `allowed_vlans` | `native_vlan` |
| `assign_vlan_to_trunk_port` | `interface`, `allowed_vlans` | None |
| `configure_trunk_allowed_vlans` | `interface`, `allowed_vlans` | None |
| `set_native_vlan` | `interface`, `native_vlan` | None |
| `configure_loopback_interface` | `interface`, `address`, `prefix_length` | `description` |
| `configure_port_channel` | `aggregate_interface`, `member_interfaces`, `lacp_mode` | `description` |
| `configure_static_route` | `destination`, `next_hop` | `preference` |
| `add_default_route` | `next_hop` | `preference` |
| `add_floating_static_route` | `destination`, `next_hop`, `preference` | None |
| `enable_ospf_process` | `process_id`, `router_id` | None |
| `set_ospf_router_id` | `process_id`, `router_id` | None |
| `create_ospf_area` | `process_id`, `area`, `area_type` | None |
| `assign_interface_to_ospf_area` | `process_id`, `interface`, `area` | None |
| `advertise_network` | `process_id`, `network_prefix`, `area` | None |
| `configure_passive_interface` | `process_id`, `interface`, `passive` | None |
| `configure_ospf_redistribution` | `process_id`, `redistribution_source`, `route_policy`, `ospf_metric`, `metric_type` | None |
| `create_acl` | `acl_name`, `description` | None |
| `add_acl_rule` | `acl_name`, `acl_rule_id`, `acl_action`, `source_prefix`, `destination_prefix`, `ip_protocol` | `source_port`, `destination_port`, `log` |
| `modify_acl_rule` | `acl_name`, `acl_rule_id`, `acl_action`, `source_prefix`, `destination_prefix`, `ip_protocol` | `source_port`, `destination_port`, `log` |
| `delete_acl_rule` | `acl_name`, `acl_rule_id` | None |
| `apply_acl_to_interface` | `acl_name`, `interface`, `direction` | None |
| `create_qos_policy` | `policy_name`, `policy_terms` | None |
| `create_classifier` | `classifier_name`, `dscp_values`, `match_mode` | None |
| `classify_by_dscp` | `classifier_name`, `dscp_values`, `previous_dscp_values` | None |
| `configure_scheduler` | `policy_name`, `classifier_name`, `bandwidth_bps` | None |
| `configure_shaping` | `policy_name`, `interface`, `rate_bps`, `direction` | None |
| `configure_policing` | `policy_name`, `interface`, `rate_bps`, `burst_bytes`, `direction`, `exceed_action` | None |
| `apply_qos_policy_to_interface` | `policy_name`, `interface`, `direction` | None |

## Why Missing Bindings Are Still Missing

The remaining work is real vendor implementation, not vector insertion.
Equivalent behavior must be defined, required vendor inputs mapped, templates
added, device policies extended, contracts versioned and a new release published.
This update does not claim those 54 combinations were implemented.

For example, Junos scheduling associates schedulers with forwarding classes
through scheduler maps ([Juniper EX scheduler documentation](https://www.juniper.net/documentation/us/en/software/junos/cos-ex/topics/concept/cos-ex-series-schedulers-understanding.html)).
Huawei traffic policy configuration binds classifiers to traffic behaviors
([CloudEngine V200R024C10 reference](https://support.huawei.com/enterprise/en/doc/EDOC1100468598/4a6f9703/statistics-configuration-commands)).
A scheduler name and bandwidth alone cannot silently supply those missing
relationships. The same first-pass fields therefore cannot promise equivalent
configuration on every vendor.

Use [the prompt guide](PROMPT_TESTING_GUIDE.md) for the existing coverage.
See [activation results](KNOWLEDGE_ACTIVATION_RESULTS.md) for the active release
and the weak-model limitation observed during prompting.
