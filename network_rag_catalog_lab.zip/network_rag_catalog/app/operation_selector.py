import json,re
from .llm import llm

def select_operation(prompt,category,candidates):
    listing='\n'.join(f"- {x['operation_id']}: {x['description']}" for x in candidates)
    sys=f'''The category is {category}. Choose exactly one operation from these retrieved candidates:\n{listing}\nReturn JSON only: {{"operation_id":"..."}}. Never invent an operation.'''
    raw=llm.invoke([('system',sys),('human',prompt)]).content.strip()
    try: op=json.loads(raw)['operation_id']
    except Exception:
        m=re.search(r'"operation_id"\s*:\s*"([^"]+)"',raw,re.I); op=m.group(1) if m else ''
    allowed={x['operation_id'] for x in candidates}
    if op not in allowed: raise ValueError(f'Invalid operation selection: {raw}')
    return op
